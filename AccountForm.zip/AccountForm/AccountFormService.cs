using Kayala.Objects;
using Kayala.Query;
using Kayala.Services;

namespace AccountFormService
{
	[Service]
	public class AccountPrintService : BaseService
	{
		[ServiceMethod]
		public void Print(MethodContext context)
		{
			var doc = context.DocObject;

			var rep = CreateReport("Счет.tcrp");
			rep.AddSection("Header");
			rep.SetSectionObject(doc);

			var criteria = new QueryCriteria("Счета")
				.Min("Code", "Code")
				.WhereDictNotDeleted();
			var query = ExecuteQuery(criteria);
			var account = query.Read() ? (DictionaryObject)query["Code"] : null;

			rep.SetParameter("Банк", account != null ? (string)account["Банк"] : "");
			rep.SetParameter("БИК банка", account != null ? (string)account["Банк"]["БИК"] : "");
			rep.SetParameter("Корр счет", account != null ? (string)account["Банк"]["Корр счет"] : "");
			rep.SetParameter("Номер счета", account != null ? account.Name : "");

			var table = doc.Tables[0].CreateIterator();
			while (table.Read())
			{
				rep.AddSection("TableRow");
				rep.SetSectionObject(table);
			}

			rep.AddSection("Footer");
			rep.SetSectionObject(doc);
		}
	}
}

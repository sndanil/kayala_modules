using Kayala.Objects;
using Kayala.Query;
using Kayala.Services;

namespace Tn2PrintService
{
	[Service]
	public class Tn2PrintService : BaseService
	{
		[ServiceMethod]
		public void Print(MethodContext context)
		{
			var doc = context.DocObject;

			var report = CreateReport("ТН-2.tcr");
			report.AddSection("Header");
			report.SetSectionObject(doc);
			report.AddSection("TableHeader");
			report.SetSectionObject(doc);

			var line = 1;
			var table = doc.Tables[0].CreateIterator();
			while (table.Read())
			{
				report.AddSection("TableRow");
				report.SetSectionObject(table);

				if (line == 10)
				{
					report.AddSection("Footer");
					report.SetSectionObject(doc);

					report = CreateReport("ТН-2.Приложение.tcr");
					report.AddSection("Header");
					report.SetSectionObject(doc);
					report.AddSection("TableHeader");
					report.SetSectionObject(doc);
				}

				line++;
			}

			report.AddSection("Footer");
			report.SetSectionObject(doc);
		}
	}
}

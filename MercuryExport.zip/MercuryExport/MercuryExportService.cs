﻿using Kayala.Objects;
using Kayala.Query;
using Kayala.Services;
using Kayala.Database;
using System;
using System.Collections.Generic;
using System.Linq;

namespace MercuryExportService
{
	[Service]
	public class MercuryExportService : BaseService
	{
		private const int MaxNameLength = 56;

		[ServiceMethod]
		public void Run(string path, bool withDeleted, IEnumerable<int> goods)
		{
			var criteria = (goods?.Any() == true
				? QueryHelper.GetAllCodes(AppContext, "Товары", goods)
				: new QueryCriteria("Товары").Select("Code"))
				.WhereDictIsNotGroup();
			if (!withDeleted)
				criteria.WhereDictNotDeleted();
			var query = ExecuteQuery(criteria);

			var codes = (goods?.Any() == true) ? query.AsEnumerable().Select(r => (int)r["Code"]).ToList() : null;
			var pricesSvc = AppContext.Services.GetService<IPrices>();
			var salePrices = pricesSvc.GetSalePrices(null, codes, null) ?? new Dictionary<int, decimal>();

			criteria = new QueryCriteria("Штрихкоды")
				.Select("Owner")
				.Select("Name")
				.WhereDictNotDeleted();
			var barcodes = ExecuteQuery(criteria)
				.AsEnumerable()
				.Select(r => new { Good = (int)r["Owner"], Barcode = (string)r["Name"] })
				.ToList();

			var lines = new List<string>();
			while (query.Read())
			{
				var good = (DictionaryObject)query["Code"];
				decimal price;
				if (salePrices.TryGetValue(good.Code, out price) && price > 0)
				{
					var barCode = barcodes.Where(b => b.Good == good.Code).Select(b => b.Barcode).FirstOrDefault();
					lines.Add($"{good.Code};{barCode};{price.ToString(System.Globalization.CultureInfo.InvariantCulture)};;{((int)good["GoodType"] == 1 ? 1 : 0)};;0;{good.Name.Replace(";", " ").Trim().Truncate(MaxNameLength)}");
				}
			}

			System.IO.File.WriteAllLines(path, lines, System.Text.Encoding.GetEncoding(1251));
			this.Context.Console.Write($"Выгрузка в файл '{path}' завершена.");
		}
	}

	public interface IPrices
	{
		Dictionary<int, decimal> GetSalePrices(DateTime? date, IEnumerable<int> goods, int? pricesType);
		Dictionary<int, decimal> GetIncomePrices(DateTime? date, IEnumerable<int> goods);
	}
}

using System.IO;
using System.Collections.Generic;
using System;
using System.Linq;
using System.Text;
using Kayala.Objects;
using Kayala.Query;
using Kayala.Services;
using Kayala.UI;
using Kayala.Cache;
using Kayala.Events;
using Kayala.Metadata.Fields;

namespace RMKFastSelect
{
	[Service]
	public class RMKFastSelectService : Kayala.Services.BaseService
	{
		[ServiceMethod]
		public void GetFastGoods(int pos, out int[] fastGoods)
		{		
			var criteria = new QueryCriteria("Товары быстрого подбора")
				.WhereDictNotDeleted()
				.Select("Good")
				.Where("Owner = @Owner", pos);
			
			fastGoods = AppContext.Repository.ExecuteQuery(criteria).AsEnumerable().Select(r => (int)r["Good"]).ToArray();;
		}
	}
}
